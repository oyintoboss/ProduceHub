export interface Supplier {
}
