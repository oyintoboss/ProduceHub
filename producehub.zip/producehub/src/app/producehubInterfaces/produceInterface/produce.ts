export interface Produce {
    produceId: string;
		name: string;
		description: string;
		imageUrl: string;
}
