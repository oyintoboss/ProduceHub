export interface Buyer {
}
