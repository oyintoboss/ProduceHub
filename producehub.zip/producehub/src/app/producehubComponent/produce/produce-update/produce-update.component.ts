import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-produce-update',
  templateUrl: './produce-update.component.html',
  styleUrls: ['./produce-update.component.css']
})
export class ProduceUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
