import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-update',
  templateUrl: './supplier-update.component.html',
  styleUrls: ['./supplier-update.component.css']
})
export class SupplierUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
