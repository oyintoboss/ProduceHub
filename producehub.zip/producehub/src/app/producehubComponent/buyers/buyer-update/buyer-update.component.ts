import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyer-update',
  templateUrl: './buyer-update.component.html',
  styleUrls: ['./buyer-update.component.css']
})
export class BuyerUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
